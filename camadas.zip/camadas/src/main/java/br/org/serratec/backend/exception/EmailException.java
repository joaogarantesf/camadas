package br.org.serratec.backend.exception;

public class EmailException extends Exception{

	public EmailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
