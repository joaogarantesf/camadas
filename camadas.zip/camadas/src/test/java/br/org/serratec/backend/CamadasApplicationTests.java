package br.org.serratec.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamadasApplicationTests {

	@Test
	void contextLoads() {
	}

}
