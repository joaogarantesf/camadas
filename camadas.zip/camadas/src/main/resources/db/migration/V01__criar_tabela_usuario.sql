CREATE TABLE usuario(id_usuario serial primary key, 
nome varchar(40), email varchar(30),
perfil varchar(30), senha varchar(255));
